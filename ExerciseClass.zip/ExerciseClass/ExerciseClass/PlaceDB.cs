﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace swiming.BLL
{
    class PlaceDB:GeneralDB
    {
        public PlaceDB() : base("Places") { }
        protected List<Place> l = new List<Place>();
       private void DataTableToList()
       {
            foreach (DataRow dr in table.Rows)
            {
                l.Add(new Place(dr));
            }
       }

        public List<Place> GetList()
        {
            l.Clear();
            DataTableToList();
            return l;
        }
        public void AddNew(Place c)
        {
            c.Dr = table.NewRow();
            c.FillDataRow();
            this.Add(c.Dr);
        }
        public Place Find(int cod)
        {
            return this.GetList().Find(x => x.Code == cod);
        }
        public void UpdateRow(Place c)
        {
            c.FillDataRow();
            this.Update();
        }
        public void DeleteRow(int code)
        {
           Place c = this.Find(code);
            if (c != null)
            {
                c.Dr.Delete();
                this.Update();
            }
        }
    }
}
